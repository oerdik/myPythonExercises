# -*- coding: utf-8 -*-
import pandas as pd
data = [10,20,30,40,50]
df = pd.DataFrame(data)
print(df)

data2 =[["Oguzhan",22,"İzmir"],["Hulusi",29,"Isparta"],["Halil",55,"Afyon"]]

df2=pd.DataFrame(data2,columns=["İsim","Yaş","Şehir"],index=[1,2,3])

print(df2)

print("**********************")
data3 = {"İsim":["Oğuzhan","Halil","Hulusi"],
         "Yaş":[22,55,29],
         "Şehir": ["İzmir","Afyon","Isparta"]}

df3 = pd.DataFrame(data3,columns=["İsim","Yaş","Şehir"],index=[1,2,3])

print(df3["İsim"])

# del df3["Şehir"]
# df3.pop("Şehir") #silme
print(df3)
print("**********************")
print(df3.loc[2]) #veriyi çağırma
print("**********************")
print(df3.iloc[1])

df4 = df3.append(df2)
print(df4)
print("**********************")
print(df4.head()) #ilk baştaki 5 datayı ver
print("**********************")
print(df4.tail()) #sondaki 5 datayı ver
