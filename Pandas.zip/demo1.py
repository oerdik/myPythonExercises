# -*- coding: utf-8 -*-

import pandas as pd

notlar = pd.read_csv("grades.csv")
notlar.columns = ["İsim","Soyisim","SSN",
                  "Test1","Test2",
                  "Test3","Test4","Final","Sonuç"]
print(notlar.head())
print(notlar.tail(1))
print(notlar["Sonuç"])
print(notlar.iloc[3])
print(notlar[2:7])