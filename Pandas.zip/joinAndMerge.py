# -*- coding: utf-8 -*-
##### JOIN IŞLEMI ######

import pandas as pd
data1 = {
            'id':[1,3,2,7],
            'ad':['Oguzhan','Merve','Zeyno','Göko'],
            'soyad':['erd','gnr','onal','aks']
        }

data2 = {
            'id':[1,2,3,4],
            'ad':['ecü','ayla','berk','yagiz'],
            'soyad':['asd','fgb','tyu','klm']
        }
data1Df = pd.DataFrame(data1)
data2Df = pd.DataFrame(data2)

print(data1Df)
print(data2Df)

#inner right left joinlerle merge yapmak

print(pd.merge(data1Df,data2Df,on='id',how = 'inner')) #sadece 1 2 3 kaydı gelir
print(pd.merge(data1Df,data2Df,on='id',how = 'left'))
print(pd.merge(data1Df,data2Df,on='id',how = 'right'))
#Concat işlemleri
print(pd.concat([data1Df,data2Df],axis = 1))
print(pd.concat([data1Df,data2Df]))