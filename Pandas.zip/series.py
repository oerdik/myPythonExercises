# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np


data = np.array(["oguzhan","halil","hulusi"])
s = pd.Series(data,index=[1,2,3])
print(s)


data2 = {"matematik":10 , "fizik":20 , "beden egitimi":100}
s2 = pd.Series(data2,index=["fizik","matematik","beden egitimi"])
print(s2)

print(s2[1])
print(s2["fizik"])

s3 = pd.Series(5,index=[1,2,3,4,5])
print(s3)