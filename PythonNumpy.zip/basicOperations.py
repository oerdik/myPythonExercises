# -*- coding: utf-8 -*-
import numpy as np

a = np.array([20,30,40,50])
b = np.arange(4)

c = a-b
d = b**2
e = 10 * np.sin(a)
print(e<7) #true false döner
print(a*b)# elementwise product
print(a@b)#matris çapımı
print(a.dot(b))#matris çarpımı

f = np.ones((2,4)) #ikiye dörtlük 1 ler oluştur
g = np.zeros(2,4) #ikiye dörtlük 0 lar oluştur
h = np.random.random((2,4)) #0 ve 1 arasında random ikiye dörtlük sayılar üret
i = np.sum(b) # topla
print(b.sum())

j = np.min(b)
k = np.max(h)
l = np.sqrt(b) # karekokleri

