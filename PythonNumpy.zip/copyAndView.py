# -*- coding: utf-8 -*-
import numpy as np

a = np.arange(10)
print(a)

b = a

print( a[2])
print( b[2])

b[0] = 100 #Referans ataması
print(a)
print(b)
#Veri Kopyalama
c = a.copy()
print(c)
c[0] = 1000
print(a)
print(c)

#View

d = a.view()
d.shape = 2,5
print(a)
print(d)
a[0] = 123
print(a)
print(d)
