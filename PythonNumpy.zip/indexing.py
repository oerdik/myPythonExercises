# -*- coding: utf-8 -*-
import numpy as np

sayilar = np.array([0,5,10,15,20,25,30])
print(sayilar[::-1]) # tersten dizdi
# print(sayilar[6])
# print(sayilar[0:3])

sayilar2 = np.array([[0,5,10],[15,20,25]])
print(sayilar2[:,2]) # 0,1 1. dizinin 2. elemanını ver 1,2 2.dizinin 3. elemanını ver : tüm satırları ver
print(sayilar2[:,0:2])
print(sayilar2[-1,:]) #son satırı ver
print(sayilar2[:,-1]) # son sütünu ver


