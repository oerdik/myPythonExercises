import numpy as np

havaDurumu =[[12,21,31],[6,17,18],[11,12,13]]

# print(havaDurumu)

a = np.arange(15).reshape(3,5) #np.arrange diziyi oluşturdu, reshape 5 elemanlı 3 dizite böldü

print(a)

b = np.arange(10)
print(b.shape)
print(b.ndim) # boyutu gösteririr tek satır
print(a.ndim) #reshape yaptığımız için 2 boyutlu oldu 3 satır 2 sutun


