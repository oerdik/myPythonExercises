import numpy as np

a = np.linspace(1,10,5) #1 den 10a eşit aralıklarla artan 5 sayı

print(a)


from numpy import pi

x = np.linspace(0, 2*pi,100)
print(x)

print(np.sin(x)) #0 dereceyle 360 derecenin sinüslerini hesaplama