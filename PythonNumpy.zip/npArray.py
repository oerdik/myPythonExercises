import numpy as np

# a = np.arange(1,10)

a = np.array([1,3,5,7,9,11]) 
a = a.reshape(3,2) #Referans alması gerekir
print(a)
print(a.dtype)

b = np.array([[1,3],[5,7],[9,11]])

print(b)
print(b.ndim)