import numpy as np
a = np.floor(10*np.random.random((3,6)))
print(a)

print(a.shape)
print(a.ravel()) #flatten düz hale getirdi
print(a)
a = a.ravel()
print(a)
print(a.shape)
print(a.reshape(2,9))
a = a.reshape(2,9)
print(a.T) #transpoz hali

print(a.reshape(2,-1))
