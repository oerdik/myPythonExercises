# -*- coding: utf-8 -*-
import numpy as np


a = np.floor(10*np.random.random((2,3)))
b = np.floor(10*np.random.random((2,3)))
print(a)
print(b)
c = np.vstack((a,b)) #vertical stack dikey birleştirme sütün sayısı değiştirmek istemediğimizde
print(c)
d = np.hstack((a,b)) #horizental stack atay birleştirme satır sayısını değiştirmek istemediğimizde
print(d)

